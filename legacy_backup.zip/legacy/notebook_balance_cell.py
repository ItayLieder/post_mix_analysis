# 🎚️ CLEAN BALANCE CONTROL - Add this cell to your notebook

from controls.balance_control import create_balance_controls, quick_balance

# Method 1: Quick one-liner for common adjustments
# ================================================
# Uncomment one of these:

# channel_overrides = quick_balance(channels, drums=4.0, vocals=0.3, bass=1.5)
# channel_overrides = quick_balance(channels, drums=2.0, vocals=0.5)
# channel_overrides = quick_balance(channels, vocals=2.0, drums=0.5)

# Method 2: Interactive control system
# ====================================
if 'channels' in locals() and channels:
    # Create the control system
    controls = create_balance_controls(channels)
    
    print("🎚️ BALANCE CONTROL READY")
    print("=" * 50)
    print("Commands available:")
    print("  controls.boost_drums(4.0)      # Boost drums 4x")
    print("  controls.reduce_vocals(0.3)    # Reduce vocals to 30%")
    print("  controls.boost_bass(1.5)       # Boost bass 1.5x")
    print("  controls.set_category('guitars', 0.8)")
    print("  controls.set_channel('keys.piano4', 2.0)")
    print("  controls.apply_preset('drum_power')")
    print("  controls.show()                # See current settings")
    print("  controls.reset()               # Reset all")
    print("\nPresets: 'drum_power', 'vocal_focus', 'balanced', 'instrumental'")
    print("=" * 50)
    
    # Example usage - modify as needed:
    controls.boost_drums(4.0)
    controls.reduce_vocals(0.3)
    controls.boost_bass(1.5)
    
    # Get the final overrides for mixing engine
    channel_overrides = controls.get_overrides()
    
    print(f"\n✅ Ready for mixing: {len(channel_overrides)} overrides set")
    
else:
    print("❌ No channels loaded - run channel loading cell first")